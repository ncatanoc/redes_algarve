package tcp_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class handshake_ACK{
	/*@ spec_public */ private tcp0 machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public handshake_ACK(tcp0 m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_endpoint().has(x) && machine.get_endpoint().has(y) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(x,y)) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(y,x)) && machine.get_connection_state().apply(new Pair<Integer,Integer>(x,y)).equals(machine.CLOSE) && machine.get_connection_state().apply(new Pair<Integer,Integer>(y,x)).equals(machine.CLOSE)); */
	public /*@ pure */ boolean guard_handshake_ACK( Integer x, Integer y) {
		return (machine.get_endpoint().has(x) && machine.get_endpoint().has(y) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(x,y)) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(y,x)) && machine.get_connection_state().apply(new Pair<Integer,Integer>(x,y)).equals(machine.CLOSE) && machine.get_connection_state().apply(new Pair<Integer,Integer>(y,x)).equals(machine.CLOSE));
	}

	/*@ public normal_behavior
		requires guard_handshake_ACK(x,y);
		assignable machine.connection_state, machine.stream;
		ensures guard_handshake_ACK(x,y) &&  machine.get_connection_state().equals(\old((machine.get_connection_state().override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),machine.OPEN),new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(y,x),machine.OPEN)))))) &&  machine.get_stream().equals(\old((machine.get_stream().override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),1)))))); 
	 also
		requires !guard_handshake_ACK(x,y);
		assignable \nothing;
		ensures true; */
	public void run_handshake_ACK( Integer x, Integer y){
		if(guard_handshake_ACK(x,y)) {
			BRelation<Pair<Integer,Integer>,Integer> connection_state_tmp = machine.get_connection_state();
			BRelation<Pair<Integer,Integer>,Integer> stream_tmp = machine.get_stream();

			machine.set_connection_state((connection_state_tmp.override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),machine.OPEN),new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(y,x),machine.OPEN)))));
			machine.set_stream((stream_tmp.override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),1)))));

			System.out.println("handshake_ACK executed x: " + x + " y: " + y + " ");
		}
	}

}
