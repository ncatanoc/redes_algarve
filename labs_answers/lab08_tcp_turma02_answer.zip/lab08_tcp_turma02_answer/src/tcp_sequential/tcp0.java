package tcp_sequential;

import eventb_prelude.*;
import Util.*;
//@ model import org.jmlspecs.models.JMLObjectSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class tcp0{
	private static final Integer max_integer = Utilities.max_integer;
	private static final Integer min_integer = Utilities.min_integer;

	to_send evt_to_send = new to_send(this);
	handshake_SYN_ACK evt_handshake_SYN_ACK = new handshake_SYN_ACK(this);
	handshake_ACK evt_handshake_ACK = new handshake_ACK(this);
	handshake_SYN evt_handshake_SYN = new handshake_SYN(this);
	handshake_FIN evt_handshake_FIN = new handshake_FIN(this);
	to_receive evt_to_receive = new to_receive(this);


	/******Set definitions******/
	//@ public static constraint STATE.equals(\old(STATE)); 
	public static final BSet<Integer> STATE = new Enumerated(min_integer,max_integer);

	//@ public static constraint ENDPOINT.equals(\old(ENDPOINT)); 
	public static final BSet<Integer> ENDPOINT = new Enumerated(min_integer,max_integer);

	//@ public static constraint FLAG.equals(\old(FLAG)); 
	public static final BSet<Integer> FLAG = new Enumerated(min_integer,max_integer);

	//@ public static constraint DATA.equals(\old(DATA)); 
	public static final BSet<Integer> DATA = new Enumerated(min_integer,max_integer);


	/******Constant definitions******/
	//@ public static constraint CLOSE.equals(\old(CLOSE)); 
	public static final Integer CLOSE = 0;

	//@ public static constraint OPEN.equals(\old(OPEN)); 
	public static final Integer OPEN = 1;



	/******Axiom definitions******/
	/*@ public static invariant STATE.equals(new BSet<Integer>(OPEN,CLOSE)); */


	/******Variable definitions******/
	/*@ spec_public */ private BSet<Integer> endpoint;

	/*@ spec_public */ private BRelation<Pair<Integer,Integer>,Integer> stream;

	/*@ spec_public */ private BRelation<Pair<Integer,Integer>,Integer> received;

	/*@ spec_public */ private BRelation<Pair<Integer,Integer>,Integer> sent;

	/*@ spec_public */ private BRelation<Pair<Integer,Integer>,Integer> connection_state;




	/******Invariant definition******/
	/*@ public invariant
		endpoint.isSubset(ENDPOINT) &&
		 connection_state.domain().isSubset(BRelation.cross(endpoint,endpoint)) && connection_state.range().isSubset(STATE) && connection_state.isaFunction() && BRelation.cross(BRelation.cross(endpoint,endpoint),STATE).has(connection_state) &&
		 sent.domain().isSubset(BRelation.cross(endpoint,endpoint)) && sent.range().isSubset(NAT.instance) && sent.isaFunction() && BRelation.cross(BRelation.cross(endpoint,endpoint),NAT.instance).has(sent) &&
		 received.domain().isSubset(BRelation.cross(endpoint,endpoint)) && received.range().isSubset(NAT.instance) && received.isaFunction() && BRelation.cross(BRelation.cross(endpoint,endpoint),NAT.instance).has(received) &&
		 stream.domain().isSubset(BRelation.cross(endpoint,endpoint)) && stream.range().isSubset(NAT.instance) && stream.isaFunction() && BRelation.cross(BRelation.cross(endpoint,endpoint),NAT.instance).has(stream); */


	/******Getter and Mutator methods definition******/
	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.endpoint;*/
	public /*@ pure */ BSet<Integer> get_endpoint(){
		return this.endpoint;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.endpoint;
	    ensures this.endpoint == endpoint;*/
	public void set_endpoint(BSet<Integer> endpoint){
		this.endpoint = endpoint;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.stream;*/
	public /*@ pure */ BRelation<Pair<Integer,Integer>,Integer> get_stream(){
		return this.stream;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.stream;
	    ensures this.stream == stream;*/
	public void set_stream(BRelation<Pair<Integer,Integer>,Integer> stream){
		this.stream = stream;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.received;*/
	public /*@ pure */ BRelation<Pair<Integer,Integer>,Integer> get_received(){
		return this.received;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.received;
	    ensures this.received == received;*/
	public void set_received(BRelation<Pair<Integer,Integer>,Integer> received){
		this.received = received;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.connection_state;*/
	public /*@ pure */ BRelation<Pair<Integer,Integer>,Integer> get_connection_state(){
		return this.connection_state;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.connection_state;
	    ensures this.connection_state == connection_state;*/
	public void set_connection_state(BRelation<Pair<Integer,Integer>,Integer> connection_state){
		this.connection_state = connection_state;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.sent;*/
	public /*@ pure */ BRelation<Pair<Integer,Integer>,Integer> get_sent(){
		return this.sent;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.sent;
	    ensures this.sent == sent;*/
	public void set_sent(BRelation<Pair<Integer,Integer>,Integer> sent){
		this.sent = sent;
	}



	/*@ public normal_behavior
	    requires true;
	    assignable \everything;
	    ensures
		endpoint.isEmpty() &&
		connection_state.isEmpty() &&
		sent.isEmpty() &&
		received.isEmpty() &&
		stream.isEmpty();*/
	public tcp0(){
		endpoint = new BSet<Integer>();
		connection_state = new BRelation<Pair<Integer,Integer>,Integer>();
		sent = new BRelation<Pair<Integer,Integer>,Integer>();
		received = new BRelation<Pair<Integer,Integer>,Integer>();
		stream = new BRelation<Pair<Integer,Integer>,Integer>();

	}
}