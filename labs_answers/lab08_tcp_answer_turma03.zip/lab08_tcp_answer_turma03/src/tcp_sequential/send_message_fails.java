package tcp_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class send_message_fails{
	/*@ spec_public */ private tcp0 machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public send_message_fails(tcp0 m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (NAT1.instance.has(n) && machine.get_endpoint().has(x) && machine.get_endpoint().has(y) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(x,y)) && !machine.get_connection_state().apply(new Pair<Integer,Integer>(x,y)).equals(machine.CLOSE) && machine.get_stream().domain().has(new Pair<Integer,Integer>(x,y))); */
	public /*@ pure */ boolean guard_send_message_fails( Integer n, Integer x, Integer y) {
		return (NAT1.instance.has(n) && machine.get_endpoint().has(x) && machine.get_endpoint().has(y) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(x,y)) && !machine.get_connection_state().apply(new Pair<Integer,Integer>(x,y)).equals(machine.CLOSE) && machine.get_stream().domain().has(new Pair<Integer,Integer>(x,y)));
	}

	/*@ public normal_behavior
		requires guard_send_message_fails(n,x,y);
		assignable machine.lost_and_found;
		ensures guard_send_message_fails(n,x,y) &&  machine.get_lost_and_found().equals(\old((machine.get_lost_and_found().override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),n)))))); 
	 also
		requires !guard_send_message_fails(n,x,y);
		assignable \nothing;
		ensures true; */
	public void run_send_message_fails( Integer n, Integer x, Integer y){
		if(guard_send_message_fails(n,x,y)) {
			BRelation<Pair<Integer,Integer>,Integer> lost_and_found_tmp = machine.get_lost_and_found();

			machine.set_lost_and_found((lost_and_found_tmp.override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),n)))));

			System.out.println("send_message_fails executed n: " + n + " x: " + x + " y: " + y + " ");
		}
	}

}
