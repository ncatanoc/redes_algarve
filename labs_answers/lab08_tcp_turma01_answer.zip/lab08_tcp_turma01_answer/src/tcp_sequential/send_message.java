package tcp_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class send_message{
	/*@ spec_public */ private tcp0 machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public send_message(tcp0 m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (NAT1.instance.has(n) && machine.get_endpoint().has(x) && machine.get_endpoint().has(y) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(x,y)) && !machine.get_connection_state().apply(new Pair<Integer,Integer>(x,y)).equals(machine.CLOSE) && machine.get_stream().domain().has(new Pair<Integer,Integer>(x,y)) && machine.get_sent().domain().has(new Pair<Integer,Integer>(x,y))); */
	public /*@ pure */ boolean guard_send_message( Integer n, Integer x, Integer y) {
		return (NAT1.instance.has(n) && machine.get_endpoint().has(x) && machine.get_endpoint().has(y) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(x,y)) && !machine.get_connection_state().apply(new Pair<Integer,Integer>(x,y)).equals(machine.CLOSE) && machine.get_stream().domain().has(new Pair<Integer,Integer>(x,y)) && machine.get_sent().domain().has(new Pair<Integer,Integer>(x,y)));
	}

	/*@ public normal_behavior
		requires guard_send_message(n,x,y);
		assignable machine.stream, machine.sent;
		ensures guard_send_message(n,x,y) &&  machine.get_stream().equals(\old((machine.get_stream().override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),new Integer(n + machine.get_stream().apply(new Pair<Integer,Integer>(x,y))))))))) &&  machine.get_sent().equals(\old((machine.get_sent().override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),new Integer(n + machine.get_sent().apply(new Pair<Integer,Integer>(x,y))))))))); 
	 also
		requires !guard_send_message(n,x,y);
		assignable \nothing;
		ensures true; */
	public void run_send_message( Integer n, Integer x, Integer y){
		if(guard_send_message(n,x,y)) {
			BRelation<Pair<Integer,Integer>,Integer> stream_tmp = machine.get_stream();
			BRelation<Pair<Integer,Integer>,Integer> sent_tmp = machine.get_sent();

			machine.set_stream((stream_tmp.override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),new Integer(n + stream_tmp.apply(new Pair<Integer,Integer>(x,y))))))));
			machine.set_sent((sent_tmp.override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),new Integer(n + sent_tmp.apply(new Pair<Integer,Integer>(x,y))))))));

			System.out.println("send_message executed n: " + n + " x: " + x + " y: " + y + " ");
		}
	}

}
