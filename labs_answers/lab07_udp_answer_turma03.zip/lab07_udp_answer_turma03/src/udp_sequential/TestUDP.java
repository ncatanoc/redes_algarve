package udp_sequential;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import eventb_prelude.BSet;

public class TestUDP {
	udp0 udp;

	@Before
	public void setUp() throws Exception {
		udp = new udp0();
	}

	@After
	public void tearDown() throws Exception {
	}
	

	@Test
	public void test_nestor01() {
		/* It just tests that we can transmit a packet;
		 * afterwards, it sends the packet
		 */
		
		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
	}
	

	@Test
	public void test_nestor02() {
		/* it tests that elements in variable 'dropset'
		 * are not received
		 */
		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		
		BSet<Integer> empty =  new BSet<Integer>();
		assertTrue(dropset.intersection(udp.get_received()).equals(empty));
	}

	
	@Test
	public void test_0() {
		/*  test description: test that it is not possible to send the same packet twice 
		 *  over the same 'source' and 'destination' ports.
		 */

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertFalse(guard);
	}
	

	@Test
	public void test_1() {
		/* test description : test that if all the elements of a transmitted packet are dropped,
		 * then the received set rests unchanged as a result of the transmission.
		 */

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13207;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		dropset.add(3);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertFalse(guard);
		BSet<Integer> received_before = udp.get_received();
		udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		BSet<Integer> received_after = udp.get_received();
		assertTrue(received_before.equals(received_after));
	}
	

	@Test
	public void test_2() {
		/* test description : test that if you are able to send a packet from port X to
		 * port Y, then you will NOT be able to send the same packet from port Y to port X 
		 * immediately after the first transmission.
		 */

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		boolean guard2 = udp.evt_transmit_packet.guard_transmit_packet(source, destination, packet, dropset);
		assertFalse(guard2);
	}
	

	@Test
	public void test_3() {
		/* test description: suppose that variable 'packet' is the set of numbers
		 * from 0 to 9, and  variable 'dropset' is the set of the elements from 0 to 4, then,
		 * after sending the packet, the size of variable 'received' gets incremented by 5.
		 */

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		data.add(5);
		data.add(6);
		data.add(7);
		data.add(8);
		data.add(9);
		data.add(10);
		data.add(11);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(0);
		packet.add(1);
		packet.add(2);
		packet.add(3);
		packet.add(4);
		packet.add(5);
		packet.add(6);
		packet.add(7);
		packet.add(8);
		packet.add(9);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(0);
		dropset.add(1);
		dropset.add(2);
		dropset.add(3);
		dropset.add(4);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertTrue(guard); // it is possible to transmit
		int received_before = udp.get_received().size();
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		int received_after = udp.get_received().size();
		assertTrue(received_before+5 == received_after);
	}
	

	@Test
	public void test_4() {
		/* test description : transmitting a 'packet' does not introduce new elements to the set
		 * of 'received' packets other than the ones that were sent in variable 'packet'.
		 */
		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertTrue(guard);
		
		BSet<Integer> received_before = udp.get_received();
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		BSet<Integer> received_after = udp.get_received();
		assertTrue(received_after.difference(received_before).isSubset(packet));
	}
	
	

	@Test
	public void test_5() {
		/*  test description: test that it is possible to transmit a packet to oneself.
		 * 
		 */
		
		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13201;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertTrue(guard);
	}


	@Test
	public void test_6() {
		/* test description: you should copy/paste the code of test_nestor here; 
		 * and then test that you can transmit a packet again; for the second 
		 * transmission you should use different values for ports, source, 
		 * destination, and dropset. Do not use the same values used for the first 
		 * transmission!
		 */
		

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		
		

		BSet<Integer> port2 = new BSet<Integer>();
		port2.add(132019);
		port2.add(132029);
		port2.add(132039);
		port2.add(132049);
		udp.set_port(port2);
		//
		int source2 = 132019;
		int destination2 = 132049;
		//
		BSet<Integer> data2 = new BSet<Integer>();
		data2.add(10);
		data2.add(11);
		data2.add(12);
		data2.add(13);
		data2.add(14);
		udp.set_data(data2);
		//
		BSet<Integer> packet2 = new BSet<Integer> ();
		packet2.add(11);
		packet2.add(13);
		//
		BSet<Integer> dropset2 = new BSet<Integer> ();
		dropset.add(11);
		
		boolean guard2 = udp.evt_transmit_packet.guard_transmit_packet(destination2, source2, packet2, dropset2);
		assertTrue(guard2);
	}
	

	@Test
	public void test_7() {
		/*  test description: check that if dropset is equal to packet then
		 *  the set of received packets remains unchanged as a result of the 
		 *  transmission.
		 */

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = packet;
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertTrue(guard);
		BSet<Integer> received_before = udp.get_received();
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		BSet<Integer> received_after = udp.get_received();
		assertTrue(received_before.equals(received_after));
	}
	

	@Test
	public void test_8() {
		/*  test description: test that if packet is initially empty, then the 
		 *  set of received packets remains unchanged as a result of the 
		 *  transmission.
		 */

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		//packet.add(1);
		//packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		//dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertTrue(guard);
		
		BSet<Integer> received_before = udp.get_received();
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		BSet<Integer> received_after = udp.get_received();
		assertTrue(received_before.equals(received_after));
	}
	

	@Test
	public void test_9() {		
		/*  test description: test that it is possible to send data
		 *  even when the 'source' and 'destination' ports are the same.
		 */

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = source;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertFalse(guard);
	}

}
