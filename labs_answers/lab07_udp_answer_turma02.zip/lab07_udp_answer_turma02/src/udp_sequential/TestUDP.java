package udp_sequential;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import eventb_prelude.BSet;

public class TestUDP {
	udp0 udp;

	@Before
	public void setUp() throws Exception {
		udp = new udp0();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test_nestor() {
		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		// assert 1: it is possible to transmit
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		
		BSet<Integer> empty =  new BSet<Integer>();
		// assert 2: dropset was not received 
		assertTrue(dropset.intersection(udp.get_received()).equals(empty));
		
		// assert 3: no extra data was received 
		assertTrue(udp.get_received().isSubset(packet));
	}
	

	@Test
	public void test_0() {
		/* test description : if one attempts to send a packet using 
		 * a non-existing source port, then it is impossible to transmit
		 * the packet
		 */

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13207;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertFalse(guard);

		
		/*
		 * Check INVARIANT_0 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_0 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * This is true, communication is connectionless; no connection must be established before
		 * calling the method run_transmit_packet. The method is used without any previous connection.
		 */
	}
	

	@Test
	public void test_1() {
		/* test description : test that it is impossible  to transmit a packet
		 * using a non-existing destination port
		 */

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13205;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertFalse(guard);
		
		/*
		 * Check INVARIANT_1 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_1 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * This is true. Variable 'sent' stores the sent packets; and variable 'received'
		 * store the received packets.
		 */
	}
	

	@Test
	public void test_2() {
		/* test description : all the packet elements that are sent and not dropped are received.
		 */
		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		// it is possible to transmit
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		assertTrue(udp.get_received().containsAll(packet.difference(dropset)));
		
		/*
		 * Check INVARIANT_2 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_2 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * This is true, run_transmit_packet is parametrised by ports 'source' and 'destination';
		 * transmission is not possible without proper values for those ports;
		 */
	}
	

	@Test
	public void test_3() {
		/* test description: you should test that after sending a packet,
		 * sent is equal to the union received and dropped.
		 */

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		// it is possible to transmit
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		assertTrue(udp.get_sent().equals(udp.get_received().union(udp.get_dropped())));
		
		/*
		 * Check INVARIANT_3 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_3 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * This is true; this is true of the fact that we encoded packets as sets and sets do not
		 * have a predefined order. Elements in a set can be in any order.
		 */
	}
	

	@Test
	public void test_4() {
		/* test description: you should copy/paste the code of test_nestor here; 
		 * and then test that you can transmit a packet again; for the second 
		 * transmission you should use different values for ports, source, 
		 * destination, and dropset. Do not use the same values used for the first 
		 * transmission!
		 */
		

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		// assert 1: it is possible to transmit
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		
		

		BSet<Integer> port2 = new BSet<Integer>();
		port2.add(132019);
		port2.add(132029);
		port2.add(132039);
		port2.add(132049);
		udp.set_port(port2);
		//
		int source2 = 132019;
		int destination2 = 132049;
		//
		BSet<Integer> data2 = new BSet<Integer>();
		data2.add(10);
		data2.add(11);
		data2.add(12);
		data2.add(13);
		data2.add(14);
		udp.set_data(data2);
		//
		BSet<Integer> packet2 = new BSet<Integer> ();
		packet2.add(11);
		packet2.add(13);
		//
		BSet<Integer> dropset2 = new BSet<Integer> ();
		dropset.add(11);
		
		boolean guard2 = udp.evt_transmit_packet.guard_transmit_packet(destination2, source2, packet2, dropset2);
		assertTrue(guard2);
		
		/*
		 * Check INVARIANT_4 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_4 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * This is true; elements in dropset are stored in dropped; elements in dropped are
		 * added to sent; if you check @grd2, next time you will need to pick 
		 * elements from (data∖sent), which means they are not in sent.
		 */
	}
	

	@Test
	public void test_5() {
		/*  test description: test that it is possible to transmit a packet to oneself.
		 * 
		 */
		
		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13201;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		// assert 1: it is possible to transmit
		assertTrue(guard);
		
		/*
		 * Check INVARIANT_5 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_5 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * yes, it is true; our model includes source, destination; and the payload is actually 
		 * included in sent.
		 */
	}
	

	@Test
	public void test_6() {
		/*  test description: test that if packet is initially empty, then the 
		 *  set of received packets remains unchanged as a result of the 
		 *  transmission.
		 */

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		//packet.add(1);
		//packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		//dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertTrue(guard);
		
		BSet<Integer> received_before = udp.get_received();
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		BSet<Integer> received_after = udp.get_received();
		assertTrue(received_before.equals(received_after));
		
		/*
		 * Check INVARIANT_6 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_6 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Yes, dropped packets are added to dropped and not to received.
		 */
	}
	

	@Test
	public void test_7() {
		/*  test description: check that if dropset is equal to packet then
		 *  the set of received packets remains unchanged as a result of the 
		 *  transmission.
		 */

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = packet;
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertTrue(guard);
		BSet<Integer> received_before = udp.get_received();
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		BSet<Integer> received_after = udp.get_received();
		assertTrue(received_before.equals(received_after));
		
		/*
		 * Check INVARIANT_7 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_7 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Yes, it is true; we always transmit from a source port.
		 */
	}
	
	
	
	@Test
	public void test_8() {
		/*  test description: test that it is not possible to send a packet
		 *  already sent, even if one changes source and destination ports.
		 */

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		source = 13202;
		destination = 13203;
		guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertFalse(guard);
		
		
		/*
		 * Check INVARIANT_8 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_8 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Yes, this is true; we have two independent sets for dropped and received. 
		 */
	}
	

	@Test
	public void test_9() {		
		/*  test description: test that it is not possible to send data
		 *  if dropset is not contained in the packet.
		 */

		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(0);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertFalse(guard);
		
		/*
		 * Check INVARIANT_9 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_9 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * This is false. We are storing the transmissions in a variable called datalog;
		 * for instance, you can retrieve that datalog using udp.get_datalog()  
		 */
	}

}
