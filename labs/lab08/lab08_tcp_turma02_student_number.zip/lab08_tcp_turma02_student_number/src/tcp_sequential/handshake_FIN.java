package tcp_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class handshake_FIN{
	/*@ spec_public */ private tcp0 machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public handshake_FIN(tcp0 m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_endpoint().has(x) && machine.get_endpoint().has(y) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(x,y)) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(y,x)) && machine.get_connection_state().apply(new Pair<Integer,Integer>(x,y)).equals(machine.OPEN)); */
	public /*@ pure */ boolean guard_handshake_FIN( Integer x, Integer y) {
		return (machine.get_endpoint().has(x) && machine.get_endpoint().has(y) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(x,y)) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(y,x)) && machine.get_connection_state().apply(new Pair<Integer,Integer>(x,y)).equals(machine.OPEN));
	}

	/*@ public normal_behavior
		requires guard_handshake_FIN(x,y);
		assignable machine.connection_state;
		ensures guard_handshake_FIN(x,y) &&  machine.get_connection_state().equals(\old((machine.get_connection_state().override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),machine.CLOSE)))))); 
	 also
		requires !guard_handshake_FIN(x,y);
		assignable \nothing;
		ensures true; */
	public void run_handshake_FIN( Integer x, Integer y){
		if(guard_handshake_FIN(x,y)) {
			BRelation<Pair<Integer,Integer>,Integer> connection_state_tmp = machine.get_connection_state();

			machine.set_connection_state((connection_state_tmp.override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),machine.CLOSE)))));

			System.out.println("handshake_FIN executed x: " + x + " y: " + y + " ");
		}
	}

}
