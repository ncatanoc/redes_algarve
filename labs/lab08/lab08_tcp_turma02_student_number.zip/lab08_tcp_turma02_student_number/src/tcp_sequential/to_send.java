package tcp_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class to_send{
	/*@ spec_public */ private tcp0 machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public to_send(tcp0 m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (NAT1.instance.has(n) && machine.get_endpoint().has(x) && machine.get_endpoint().has(y) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(x,y)) && machine.get_connection_state().apply(new Pair<Integer,Integer>(x,y)).equals(machine.OPEN)); */
	public /*@ pure */ boolean guard_to_send( Integer n, Integer x, Integer y) {
		boolean a = NAT1.instance.has(n);
		return (NAT1.instance.has(n) && machine.get_endpoint().has(x) && machine.get_endpoint().has(y) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(x,y)) && machine.get_connection_state().apply(new Pair<Integer,Integer>(x,y)).equals(machine.OPEN));
	}

	/*@ public normal_behavior
		requires guard_to_send(n,x,y);
		assignable machine.stream;
		ensures guard_to_send(n,x,y) &&  machine.get_stream().equals(\old((machine.get_stream().override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),n)))))); 
	 also
		requires !guard_to_send(n,x,y);
		assignable \nothing;
		ensures true; */
	public void run_to_send( Integer n, Integer x, Integer y){
		if(guard_to_send(n,x,y)) {
			BRelation<Pair<Integer,Integer>,Integer> stream_tmp = machine.get_stream();

			machine.set_stream((stream_tmp.override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),n)))));

			System.out.println("to_send executed n: " + n + " x: " + x + " y: " + y + " ");
		}
	}

}
