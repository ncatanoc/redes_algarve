package tcp_sequential;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import eventb_prelude.BSet;

public class TestTCP {
	tcp0 tcp;

	@Before
	public void setUp() throws Exception {
		tcp = new tcp0();
	}

	@After
	public void tearDown() throws Exception {
	}

	//Test
	public void test_nestor01() {
		/* it tests that a handshake can be performed,
		 *  and after the handshake we can send a "hello" message.
		 */
		BSet<Integer> endpoint = new BSet<Integer>();
		int w = 3;
		int x = 5;
		int y = 7;
		int z = 11;
		endpoint.add(w);
		endpoint.add(x);
		endpoint.add(y);
		endpoint.add(z);
		tcp.set_endpoint(endpoint);
		
		// handshake - step 1 - SYN
		boolean guard1 = tcp.evt_handshake_SYN.guard_handshake_SYN(x, y);
		assertTrue(guard1);
		tcp.evt_handshake_SYN.run_handshake_SYN(x, y);
		// handshake - step 2 - ACK+SYN
		boolean guard2 = tcp.evt_handshake_SYN_ACK.guard_handshake_SYN_ACK(x, y);
		assertTrue(guard2);
		tcp.evt_handshake_SYN_ACK.run_handshake_SYN_ACK(x, y);
		// handshake - step 3 - ACK
		boolean guard3 = tcp.evt_handshake_ACK.guard_handshake_ACK(x, y);
		assertTrue(guard3);
		tcp.evt_handshake_ACK.guard_handshake_ACK(x, y);

		// x sends n to y, where n = length("hello") = 5
		int n = 5;
		boolean guard4 = tcp.evt_to_send.guard_to_send(n, x, y);
		assertTrue(guard4);
		tcp.evt_to_send.run_to_send(n, x, y);
		
		// y receives n from x
		boolean guard5 = tcp.evt_to_receive.guard_to_receive(x, y);
		assertTrue(guard5);
		tcp.evt_to_receive.run_to_receive(x, y);
	}
	
	//Test
	public void test_0() {
		/* 
		 * you must test that you cannot send a message over a closed connection.
		 */
		assertTrue(true);
	}
	

	
	@Test
	public void test_1() {
		/* 
		 * you must test that although you close a connection from x to y, 
		 * you can still send messages from y to x.
		 */
		assertTrue(true);
	}

	
	@Test
	public void test_2() {
		/* 
		 * you must test that you cannot send messages from x to y or from y to x,
		 * if the connection between x and y is closed both ways.
		 */
		assertTrue(true);
	}
	
	@Test
	public void test_3() {
		/* 
		 * you must test that's  impossible for x to send a message to y
		 * without completing the handshake protocol first.
		 */
		assertTrue(true);
	}
	
	
	
}