package tcp_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class resend_last_message{
	/*@ spec_public */ private tcp0 machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public resend_last_message(tcp0 m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_endpoint().has(x) && machine.get_endpoint().has(y) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(x,y)) && !machine.get_connection_state().apply(new Pair<Integer,Integer>(x,y)).equals(machine.CLOSE) && machine.get_stream().domain().has(new Pair<Integer,Integer>(x,y)) && machine.get_lost_and_found().domain().has(new Pair<Integer,Integer>(x,y)) && machine.get_sent().domain().has(new Pair<Integer,Integer>(x,y))); */
	public /*@ pure */ boolean guard_resend_last_message( Integer x, Integer y) {
		return (machine.get_endpoint().has(x) && machine.get_endpoint().has(y) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(x,y)) && !machine.get_connection_state().apply(new Pair<Integer,Integer>(x,y)).equals(machine.CLOSE) && machine.get_stream().domain().has(new Pair<Integer,Integer>(x,y)) && machine.get_lost_and_found().domain().has(new Pair<Integer,Integer>(x,y)) && machine.get_sent().domain().has(new Pair<Integer,Integer>(x,y)));
	}

	/*@ public normal_behavior
		requires guard_resend_last_message(x,y);
		assignable machine.stream, machine.sent;
		ensures guard_resend_last_message(x,y) &&  machine.get_stream().equals(\old((machine.get_stream().override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),new Integer(machine.get_stream().apply(new Pair<Integer,Integer>(x,y)) + machine.get_lost_and_found().apply(new Pair<Integer,Integer>(x,y))))))))) &&  machine.get_sent().equals(\old((machine.get_sent().override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),new Integer(machine.get_sent().apply(new Pair<Integer,Integer>(x,y)) + machine.get_lost_and_found().apply(new Pair<Integer,Integer>(x,y))))))))); 
	 also
		requires !guard_resend_last_message(x,y);
		assignable \nothing;
		ensures true; */
	public void run_resend_last_message( Integer x, Integer y){
		if(guard_resend_last_message(x,y)) {
			BRelation<Pair<Integer,Integer>,Integer> stream_tmp = machine.get_stream();
			BRelation<Pair<Integer,Integer>,Integer> sent_tmp = machine.get_sent();

			machine.set_stream((stream_tmp.override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),new Integer(stream_tmp.apply(new Pair<Integer,Integer>(x,y)) + machine.get_lost_and_found().apply(new Pair<Integer,Integer>(x,y))))))));
			machine.set_sent((sent_tmp.override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),new Integer(sent_tmp.apply(new Pair<Integer,Integer>(x,y)) + machine.get_lost_and_found().apply(new Pair<Integer,Integer>(x,y))))))));

			System.out.println("resend_last_message executed x: " + x + " y: " + y + " ");
		}
	}

}
