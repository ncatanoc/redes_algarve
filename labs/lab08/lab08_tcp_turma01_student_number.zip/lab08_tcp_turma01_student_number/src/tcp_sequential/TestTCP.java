package tcp_sequential;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import eventb_prelude.*;

public class TestTCP {
	tcp0 tcp;

	@Before
	public void setUp() throws Exception {
		tcp = new tcp0();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test_nestor01() {
		/* it tests that a handshake can be performed,
		 *  and after the handshake we can send a "hello" message.
		 */
		BSet<Integer> endpoint = new BSet<Integer>();
		int w = 3;
		int x = 5;
		int y = 7;
		int z = 11;
		endpoint.add(w);
		endpoint.add(x);
		endpoint.add(y);
		endpoint.add(z);
		tcp.set_endpoint(endpoint);
		
		// handshake - step 1 - SYN
		boolean guard1 = tcp.evt_handshake_SYN.guard_handshake_SYN(x, y);
		assertTrue(guard1);
		tcp.evt_handshake_SYN.run_handshake_SYN(x, y);
		// handshake - step 2 - ACK+SYN
		boolean guard2 = tcp.evt_handshake_SYN_ACK.guard_handshake_SYN_ACK(x, y);
		assertTrue(guard2);
		tcp.evt_handshake_SYN_ACK.run_handshake_SYN_ACK(x, y);
		// handshake - step 3 - ACK
		boolean guard3 = tcp.evt_handshake_ACK.guard_handshake_ACK(x, y);
		assertTrue(guard3);
		tcp.evt_handshake_ACK.run_handshake_ACK(x, y);

		// x sends n to y, where n = length("hello") = 5
		int n = 5;
		boolean guard4 = tcp.evt_send_message.guard_send_message(n, x, y);
		assertTrue(guard4);
		tcp.evt_send_message.run_send_message(n, x, y);
		
		// y receives n from x
		boolean guard5 = tcp.evt_acknowledge_message.guard_acknowledge_message(x, y);
		assertTrue(guard5);
		tcp.evt_acknowledge_message.run_acknowledge_message(x, y);
	}
	

	@Test
	public void test_slide_21() {
		/* 
		 * Leve a cabo o teste do diagrama no diapositivo 21 da aula teórica de TCP.
		 * Deve testar completamente o exemplo mostrado pelo diagrama.
		 * Deve testar que cada mensagem (linha de esquerda a direita) consegue enviarse e finalmente se envia.
		 * Deve testar (a cada passo) que o número de bytes enviados com sucesso sãn realmente enviados.
		 * Deve testar (a cada passo) que o número de bytes recebidos con sucesso sãn realmente recebidos.
		 * Deve testar que quando uma mensagem não se envia con sucesso, os bytes enviados ficam inalterados.
		 * Deve testar que quando uma mensagem não se envia con sucesso, os bytes recebidos ficam inalterados.
		 * Dica: leve a cabo o handshake inicial antes de nada.
		 * Dica: tcp.get_sent().apply(new Pair<Integer,Integer>(x,y)) retorna os bytes enviados pelo x para o y num momento dado.
		 * Dica: tcp.get_received().apply(new Pair<Integer,Integer>(y,x)) retorna os bytes recebidos pelo y por parte do x num momento determinado.
		 * Dica: cada envio duma menssagem do x para o y, deve ser acompanhado dum acknowledgement do y para x.
		 */
	}
	
	
	
}