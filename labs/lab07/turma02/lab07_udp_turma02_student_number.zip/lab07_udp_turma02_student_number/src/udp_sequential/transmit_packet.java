package udp_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class transmit_packet{
	/*@ spec_public */ private udp0 machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public transmit_packet(udp0 m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_port().has(source) && machine.get_port().has(destination) && packet.isSubset(machine.get_data().difference(machine.get_sent())) && dropset.isSubset(packet)); */
	public /*@ pure */ boolean guard_transmit_packet( Integer destination, Integer source, BSet<Integer> packet, BSet<Integer> dropset) {
		return (machine.get_port().has(source) && machine.get_port().has(destination) && packet.isSubset(machine.get_data().difference(machine.get_sent())) && dropset.isSubset(packet));
	}

	/*@ public normal_behavior
		requires guard_transmit_packet(destination,source,packet,dropset);
		assignable machine.data, machine.sent, machine.received, machine.dropped, machine.datalog;
		ensures guard_transmit_packet(destination,source,packet,dropset) &&  machine.get_data().equals(\old((machine.get_data().union(packet)))) &&  machine.get_sent().equals(\old((machine.get_sent().union(packet)))) &&  machine.get_received().equals(\old((machine.get_received().union(packet.difference(dropset))))) &&  machine.get_dropped().equals(\old((machine.get_dropped().union(dropset)))) &&  machine.get_datalog().equals(\old((machine.get_datalog().union(new BRelation<Pair<Integer,BSet<Integer>>,BRelation<Integer,BSet<Integer>>>(new Pair<Pair<Integer,BSet<Integer>>,BRelation<Integer,BSet<Integer>>>(new Pair<Integer,BSet<Integer>>(source,packet),new BRelation<Integer,BSet<Integer>>(new Pair<Integer,BSet<Integer>>(destination,packet)))))))); 
	 also
		requires !guard_transmit_packet(destination,source,packet,dropset);
		assignable \nothing;
		ensures true; */
	public void run_transmit_packet( Integer destination, Integer source, BSet<Integer> packet, BSet<Integer> dropset){
		if(guard_transmit_packet(destination,source,packet,dropset)) {
			BSet<Integer> data_tmp = machine.get_data();
			BSet<Integer> sent_tmp = machine.get_sent();
			BSet<Integer> received_tmp = machine.get_received();
			BSet<Integer> dropped_tmp = machine.get_dropped();
			BRelation<Pair<Integer,BSet<Integer>>,BRelation<Integer,BSet<Integer>>> datalog_tmp = machine.get_datalog();

			machine.set_data((data_tmp.union(packet)));
			machine.set_sent((sent_tmp.union(packet)));
			machine.set_received((received_tmp.union(packet.difference(dropset))));
			machine.set_dropped((dropped_tmp.union(dropset)));
			machine.set_datalog((datalog_tmp.union(new BRelation<Pair<Integer,BSet<Integer>>,BRelation<Integer,BSet<Integer>>>(new Pair<Pair<Integer,BSet<Integer>>,BRelation<Integer,BSet<Integer>>>(new Pair<Integer,BSet<Integer>>(source,packet),new BRelation<Integer,BSet<Integer>>(new Pair<Integer,BSet<Integer>>(destination,packet)))))));

			System.out.println("transmit_packet executed destination: " + destination + " source: " + source + " packet: " + packet + " dropset: " + dropset + " ");
		}
	}

}
