package udp_sequential;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import eventb_prelude.BSet;

public class TestUDP {
	udp0 udp;

	@Before
	public void setUp() throws Exception {
		udp = new udp0();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test_nestor() {
		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		// assert 1: it is possible to transmit
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		
		BSet<Integer> empty =  new BSet<Integer>();
		// assert 2: dropset was not received 
		assertTrue(dropset.intersection(udp.get_received()).equals(empty));
		
		// assert 3: no extra data was received 
		assertTrue(udp.get_received().isSubset(packet));
	}
	

	@Test
	public void test_0() {
		/* test description : if one attempts to send a packet using 
		 * a non-existing source port, then it is impossible to transmit
		 * the packet
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_0 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_0 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_1() {
		/* test description : test that it is impossible  to transmit a packet
		 * using a non-existing destination port
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_1 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_1 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_2() {
		/* test description : all the packet elements that are sent and not dropped are received.
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_2 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_2 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_3() {
		/* test description: you should test that after sending a packet,
		 * sent is equal to the union received and dropped.
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_3 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_3 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_4() {
		/* test description: you should copy/paste the code of test_nestor here; 
		 * and then test that you can transmit a packet again; for the second 
		 * transmission you should use different values for ports, source, 
		 * destination, and dropset. Do not use the same values used for the first 
		 * transmission!
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_4 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_4 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_5() {
		/*  test description: test that it is possible to transmit a packet to oneself.
		 * 
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_5 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_5 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_6() {
		/*  test description: test that if packet is initially empty, then the
		 *  set of received packets remains unchanged as a result of the 
		 *  transmission.
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_6 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_6 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_7() {
		/*  test description: check that if dropset is equal to packet then
		 *  the set of received packets remains unchanged as a result of the 
		 *  transmission.
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_7 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_7 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_8() {
		/*  test description: test that it is not possible to send a packet
		 *  already sent, even if one changes source and destination ports.
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_8 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_8 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_9() {				
		/*  test description: test that it is not possible to send data
		 *  if dropset is not contained in the packet.
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_9 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_9 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}

}
