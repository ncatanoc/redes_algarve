package udp_sequential;

import eventb_prelude.*;
import Util.*;
//@ model import org.jmlspecs.models.JMLObjectSet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class udp0{
	private static final Integer max_integer = Utilities.max_integer;
	private static final Integer min_integer = Utilities.min_integer;

	transmit_packet evt_transmit_packet = new transmit_packet(this);


	/******Set definitions******/
	//@ public static constraint PORT.equals(\old(PORT)); 
	public static final BSet<Integer> PORT = new Enumerated(min_integer,max_integer);

	//@ public static constraint DATA.equals(\old(DATA)); 
	public static final BSet<Integer> DATA = new Enumerated(min_integer,max_integer);


	/******Constant definitions******/


	/******Axiom definitions******/


	/******Variable definitions******/
	/*@ spec_public */ private BSet<Integer> port;

	/*@ spec_public */ private BSet<Integer> dropped;

	/*@ spec_public */ private BRelation<Pair<Integer,BSet<Integer>>,BRelation<Integer,BSet<Integer>>> datalog;

	/*@ spec_public */ private BSet<Integer> received;

	/*@ spec_public */ private BSet<Integer> data;

	/*@ spec_public */ private BSet<Integer> sent;




	/******Invariant definition******/
	/*@ public invariant
		port.isSubset(PORT) &&
		data.isSubset(DATA) &&
		sent.isSubset(data) &&
		received.isSubset(sent) &&
		dropped.isSubset(sent) &&
		sent.equals((received.union(dropped))) &&
		 datalog.domain().isSubset(BRelation.cross(port,((data).pow()))) && datalog.range().isSubset(BRelation.cross(port,((data).pow()))) && BRelation.cross(BRelation.cross(port,((data).pow())),BRelation.cross(port,((data).pow()))).has(datalog); */


	/******Getter and Mutator methods definition******/
	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.data;*/
	public /*@ pure */ BSet<Integer> get_data(){
		return this.data;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.data;
	    ensures this.data == data;*/
	public void set_data(BSet<Integer> data){
		this.data = data;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.port;*/
	public /*@ pure */ BSet<Integer> get_port(){
		return this.port;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.port;
	    ensures this.port == port;*/
	public void set_port(BSet<Integer> port){
		this.port = port;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.dropped;*/
	public /*@ pure */ BSet<Integer> get_dropped(){
		return this.dropped;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.dropped;
	    ensures this.dropped == dropped;*/
	public void set_dropped(BSet<Integer> dropped){
		this.dropped = dropped;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.received;*/
	public /*@ pure */ BSet<Integer> get_received(){
		return this.received;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.received;
	    ensures this.received == received;*/
	public void set_received(BSet<Integer> received){
		this.received = received;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.sent;*/
	public /*@ pure */ BSet<Integer> get_sent(){
		return this.sent;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.sent;
	    ensures this.sent == sent;*/
	public void set_sent(BSet<Integer> sent){
		this.sent = sent;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable \nothing;
	    ensures \result == this.datalog;*/
	public /*@ pure */ BRelation<Pair<Integer,BSet<Integer>>,BRelation<Integer,BSet<Integer>>> get_datalog(){
		return this.datalog;
	}

	/*@ public normal_behavior
	    requires true;
	    assignable this.datalog;
	    ensures this.datalog == datalog;*/
	public void set_datalog(BRelation<Pair<Integer,BSet<Integer>>,BRelation<Integer,BSet<Integer>>> datalog){
		this.datalog = datalog;
	}



	/*@ public normal_behavior
	    requires true;
	    assignable \everything;
	    ensures
		port.isEmpty() &&
		data.isEmpty() &&
		sent.isEmpty() &&
		received.isEmpty() &&
		dropped.isEmpty() &&
		datalog.isEmpty();*/
	public udp0(){
		port = new BSet<Integer>();
		data = new BSet<Integer>();
		sent = new BSet<Integer>();
		received = new BSet<Integer>();
		dropped = new BSet<Integer>();
		datalog = new BRelation<Pair<Integer,BSet<Integer>>,BRelation<Integer,BSet<Integer>>>();

	}
}