package udp_sequential;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import eventb_prelude.BSet;

public class TestUDP {
	udp0 udp;

	@Before
	public void setUp() throws Exception {
		udp = new udp0();
	}

	@After
	public void tearDown() throws Exception {
	}



	@Test
	public void test_nestor01() {
		/* It just tests that we can transmit a packet;
		 * afterwards, it sends the packet
		 */
		
		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
	}
	

	@Test
	public void test_nestor02() {
		/* it tests that elements in variable 'dropset'
		 * are not received
		 */
		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		
		BSet<Integer> empty =  new BSet<Integer>();
		assertTrue(dropset.intersection(udp.get_received()).equals(empty));
	}
	

	@Test
	public void test_0() {
		/* test description : test that if all the elements of a transmitted are dropped,
		 * then the received set rests unchanged as a result of the transmission.
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_0 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_0 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_1() {
		/* test description : test that if you are able to send a packet from port X to
		 * port Y, then you will NOT be able to send the same packet from port Y to port X 
		 * immediately after the first transmission.
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_1 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_1 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_2() {
		/* test description: suppose that variable 'packet' is the set of numbers
		 * from 0 to 9, and  variable 'dropset' is the set of the elements from 0 to 4, then,
		 * after sending the packet, the size of variable 'received' gets incremented by 5.
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_2 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_2 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_3() {
		/* test description : transmitting a 'packet' does not introduce new elements to the set
		 * of 'received' packets other than the ones that were sent in variable 'packet'.
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_3 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_3 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_4() {
		/*  test description: test that it is possible to transmit a packet to oneself.
		 * 
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_4 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_4 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_5() {
		/* test description: you should copy/paste the code of test_nestor here; 
		 * and then test that you can transmit a packet again; for the second 
		 * transmission you should use different values for ports, source, 
		 * destination, and dropset. Do not use the same values used for the first 
		 * transmission!
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_5 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_5 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_6() {
		/*  test description: check that if dropset is equal to packet then
		 *  the set of received packets remains unchanged as a result of the 
		 *  transmission.
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_7 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_7 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_7() {
		/*  test description: test that if packet is initially empty, then the
		 *  set of received packets remains unchanged as a result of the 
		 *  transmission.
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_6 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_6 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_8() {
		/*  test description: test that it is not possible to send data
		 *  even when the 'source' and 'destination' ports are the same.
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_8 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_8 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}
	

	@Test
	public void test_9() {		
		/*  test description: test that it is not possible to send the same packet twice 
		 *  over the same 'source' and 'destination' ports.
		 */
		assertTrue(true);
		
		/*
		 * Check INVARIANT_9 in the slides of this week - 
		 * Check also the mathematical model presented in the slides -
		 * Is INVARIANT_9 true of the Java implementation of this Eclipse project?
		 * Yes/No? Why?
		 * Write Your Answer Here
		 */
	}

}
