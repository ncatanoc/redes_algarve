package tcp_sequential;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import eventb_prelude.BSet;

public class TestTCP {
	tcp0 tcp;

	@Before
	public void setUp() throws Exception {
		tcp = new tcp0();
	}

	@After
	public void tearDown() throws Exception {
	}

	//Test
	public void test_nestor01() {
		/* it tests that a handshake can be performed,
		 *  and after the handshake we can send a "hello" message.
		 */
		BSet<Integer> endpoint = new BSet<Integer>();
		int w = 3;
		int x = 5;
		int y = 7;
		int z = 11;
		endpoint.add(w);
		endpoint.add(x);
		endpoint.add(y);
		endpoint.add(z);
		tcp.set_endpoint(endpoint);
		
		// handshake - step 1 - SYN
		boolean guard1 = tcp.evt_handshake_SYN.guard_handshake_SYN(x, y);
		assertTrue(guard1);
		tcp.evt_handshake_SYN.run_handshake_SYN(x, y);
		// handshake - step 2 - ACK+SYN
		boolean guard2 = tcp.evt_handshake_SYN_ACK.guard_handshake_SYN_ACK(x, y);
		assertTrue(guard2);
		tcp.evt_handshake_SYN_ACK.run_handshake_SYN_ACK(x, y);
		// handshake - step 3 - ACK
		boolean guard3 = tcp.evt_handshake_ACK.guard_handshake_ACK(x, y);
		assertTrue(guard3);
		tcp.evt_handshake_ACK.guard_handshake_ACK(x, y);

		// x sends n to y, where n = length("hello") = 5
		int n = 5;
		boolean guard4 = tcp.evt_to_send.guard_to_send(n, x, y);
		assertTrue(guard4);
		tcp.evt_to_send.run_to_send(n, x, y);
		
		// y receives n from x
		boolean guard5 = tcp.evt_to_receive.guard_to_receive(x, y);
		assertTrue(guard5);
		tcp.evt_to_receive.run_to_receive(x, y);
	}
	
	@Test
	public void test_unique() {
		/* 
		 * you must conduct a full unit-test of the example presented in Slide 16 last week
		 * https://github.com/ncatanoc/redes_algarve/blob/main/slides/redes_sem08_tcp.pdf
		 */
		BSet<Integer> endpoint = new BSet<Integer>();
		int w = 3;
		int x = 5;
		int y = 7;
		int z = 11;
		endpoint.add(w);
		endpoint.add(x);
		endpoint.add(y);
		endpoint.add(z);
		tcp.set_endpoint(endpoint);
		
		// handshake - step 1 - SYN
		boolean guard1 = tcp.evt_handshake_SYN.guard_handshake_SYN(x, y);
		assertTrue(guard1);
		tcp.evt_handshake_SYN.run_handshake_SYN(x, y);
		// handshake - step 2 - ACK+SYN
		boolean guard2 = tcp.evt_handshake_SYN_ACK.guard_handshake_SYN_ACK(x, y);
		assertTrue(guard2);
		tcp.evt_handshake_SYN_ACK.run_handshake_SYN_ACK(x, y);
		// handshake - step 3 - ACK
		boolean guard3 = tcp.evt_handshake_ACK.guard_handshake_ACK(x, y);
		assertTrue(guard3);
		tcp.evt_handshake_ACK.run_handshake_ACK(x, y);
		
		// xxxx
	}
	

	
}