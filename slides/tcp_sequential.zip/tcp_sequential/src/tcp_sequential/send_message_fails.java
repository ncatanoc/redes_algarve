package tcp_sequential; 

import eventb_prelude.*;
import Util.Utilities;

public class send_message_fails{
	/*@ spec_public */ private tcp0 machine; // reference to the machine 

	/*@ public normal_behavior
		requires true;
		assignable \everything;
		ensures this.machine == m; */
	public send_message_fails(tcp0 m) {
		this.machine = m;
	}

	/*@ public normal_behavior
		requires true;
 		assignable \nothing;
		ensures \result <==> (machine.get_endpoint().has(x) && machine.get_endpoint().has(y) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(x,y)) && !machine.get_connection_state().apply(new Pair<Integer,Integer>(x,y)).equals(machine.CLOSE) && machine.get_stream().domain().has(new Pair<Integer,Integer>(x,y))); */
	public /*@ pure */ boolean guard_send_message_fails( Integer x, Integer y) {
		return (machine.get_endpoint().has(x) && machine.get_endpoint().has(y) && machine.get_connection_state().domain().has(new Pair<Integer,Integer>(x,y)) && !machine.get_connection_state().apply(new Pair<Integer,Integer>(x,y)).equals(machine.CLOSE) && machine.get_stream().domain().has(new Pair<Integer,Integer>(x,y)));
	}

	/*@ public normal_behavior
		requires guard_send_message_fails(x,y);
		assignable machine.stream, machine.lost_and_found;
		ensures guard_send_message_fails(x,y) &&  machine.get_stream().equals(\old((machine.get_stream().override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),0)))))) &&  machine.get_lost_and_found().equals(\old((machine.get_lost_and_found().override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),machine.get_stream().apply(new Pair<Integer,Integer>(x,y)))))))); 
	 also
		requires !guard_send_message_fails(x,y);
		assignable \nothing;
		ensures true; */
	public void run_send_message_fails( Integer x, Integer y){
		if(guard_send_message_fails(x,y)) {
			BRelation<Pair<Integer,Integer>,Integer> stream_tmp = machine.get_stream();
			BRelation<Pair<Integer,Integer>,Integer> lost_and_found_tmp = machine.get_lost_and_found();

			machine.set_stream((stream_tmp.override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),0)))));
			machine.set_lost_and_found((lost_and_found_tmp.override(new BRelation<Pair<Integer,Integer>,Integer>(new Pair<Pair<Integer,Integer>,Integer>(new Pair<Integer,Integer>(x,y),stream_tmp.apply(new Pair<Integer,Integer>(x,y)))))));

			System.out.println("send_message_fails executed x: " + x + " y: " + y + " ");
		}
	}

}
