package udp_sequential;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import eventb_prelude.BSet;

public class TestUDP {
	udp0 udp;

	@Before
	public void setUp() throws Exception {
		udp = new udp0();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test_nestor01() {
		/* It just tests that we can transmit a packet;
		 * afterwards, it sends the packet
		 */
		
		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
	}
	

	@Test
	public void test_nestor02() {
		/* it tests that elements in variable 'dropset'
		 * are not received
		 */
		BSet<Integer> port = new BSet<Integer>();
		port.add(13201);
		port.add(13202);
		port.add(13203);
		port.add(13204);
		udp.set_port(port);
		//
		int source = 13201;
		int destination = 13204;
		//
		BSet<Integer> data = new BSet<Integer>();
		data.add(0);
		data.add(1);
		data.add(2);
		data.add(3);
		data.add(4);
		udp.set_data(data);
		//
		BSet<Integer> packet = new BSet<Integer> ();
		packet.add(1);
		packet.add(3);
		//
		BSet<Integer> dropset = new BSet<Integer> ();
		dropset.add(1);
		//
		boolean guard = udp.evt_transmit_packet.guard_transmit_packet(destination, source, packet, dropset);
		assertTrue(guard);
		udp.evt_transmit_packet.run_transmit_packet(destination, source, packet, dropset);
		
		BSet<Integer> empty =  new BSet<Integer>();
		assertTrue(dropset.intersection(udp.get_received()).equals(empty));
		
		// assert 3: no extra data was received 
		assertTrue(udp.get_received().isSubset(packet));
	}
	


}
